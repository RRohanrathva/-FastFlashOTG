package com.example.fastflash

import java.io.File
import java.io.IOException
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * Android sparse image helpers: parse a sparse (or raw) image and split it into
 * several sparse pieces, each no larger than the device's max-download-size.
 */
object SparseTools {
    private const val MAGIC = -0x12d900c6 // 0xED26FF3A as signed int
    const val RAW = 0xCAC1
    const val FILL = 0xCAC2
    const val DONT_CARE = 0xCAC3
    const val CRC32 = 0xCAC4

    private const val FILE_HDR = 28
    private const val CHUNK_HDR = 12
    private const val RAW_BLOCK = 4096

    /** A run of blocks of the original image. */
    class Portion(
        val type: Int,
        val startBlock: Long,
        val blocks: Long,
        val fileOffset: Long,
        val dataBytes: Long,
        val fill: Int,
    )

    /** A chunk as it will be written into one output piece. */
    class Emit(val type: Int, val blocks: Long, val fileOffset: Long, val dataBytes: Long, val fill: Int)

    class Plan(val blockSize: Int, val totalBlocks: Long, val pieces: List<List<Portion>>)

    private fun u32(v: Int): Long = v.toLong() and 0xFFFFFFFFL

    fun isSparse(file: File): Boolean {
        if (file.length() < FILE_HDR) return false
        RandomAccessFile(file, "r").use { raf ->
            val b = ByteArray(4)
            raf.readFully(b)
            return ByteBuffer.wrap(b).order(ByteOrder.LITTLE_ENDIAN).int == MAGIC
        }
    }

    /** Builds the list of pieces for [file] so each piece is at most [limit] bytes. */
    fun plan(file: File, limit: Long): Plan {
        if (limit < 1024 * 1024) throw IOException("max-download-size too small: $limit")
        return if (isSparse(file)) planSparse(file, limit) else planRaw(file, limit)
    }

    private fun planRaw(file: File, limit: Long): Plan {
        val size = file.length()
        val blocks = (size + RAW_BLOCK - 1) / RAW_BLOCK
        val portions = listOf(Portion(RAW, 0, blocks, 0, size, 0))
        return Plan(RAW_BLOCK, blocks, split(portions, RAW_BLOCK, limit))
    }

    private fun planSparse(file: File, limit: Long): Plan {
        RandomAccessFile(file, "r").use { raf ->
            val h = ByteArray(FILE_HDR)
            raf.readFully(h)
            val bb = ByteBuffer.wrap(h).order(ByteOrder.LITTLE_ENDIAN)
            val fileHdr = bb.getShort(8).toInt() and 0xFFFF
            val chunkHdr = bb.getShort(10).toInt() and 0xFFFF
            val blk = bb.getInt(12)
            val totalBlocks = u32(bb.getInt(16))
            val totalChunks = u32(bb.getInt(20))
            if (blk <= 0 || blk % 4 != 0 || chunkHdr < CHUNK_HDR || fileHdr < FILE_HDR) {
                throw IOException("Invalid sparse header")
            }
            val portions = ArrayList<Portion>()
            var pos = fileHdr.toLong()
            var block = 0L
            val ch = ByteArray(CHUNK_HDR)
            for (i in 0 until totalChunks) {
                raf.seek(pos)
                raf.readFully(ch)
                val cb = ByteBuffer.wrap(ch).order(ByteOrder.LITTLE_ENDIAN)
                val type = cb.getShort(0).toInt() and 0xFFFF
                val chunkBlocks = u32(cb.getInt(4))
                val totalSz = u32(cb.getInt(8))
                val dataPos = pos + chunkHdr
                when (type) {
                    RAW -> {
                        portions.add(Portion(RAW, block, chunkBlocks, dataPos, chunkBlocks * blk, 0))
                        block += chunkBlocks
                    }
                    FILL -> {
                        raf.seek(dataPos)
                        val f = ByteArray(4)
                        raf.readFully(f)
                        val fill = ByteBuffer.wrap(f).order(ByteOrder.LITTLE_ENDIAN).int
                        portions.add(Portion(FILL, block, chunkBlocks, 0, 0, fill))
                        block += chunkBlocks
                    }
                    DONT_CARE -> block += chunkBlocks
                    CRC32 -> {}
                    else -> throw IOException("Unknown sparse chunk type 0x" + type.toString(16))
                }
                if (totalSz < chunkHdr) throw IOException("Corrupt sparse chunk")
                pos += totalSz
            }
            return Plan(blk, totalBlocks, split(portions, blk, limit))
        }
    }

    /** Distributes portions into pieces whose final size stays within [limit]. */
    internal fun split(portions: List<Portion>, blk: Int, limit: Long): List<List<Portion>> {
        // header + possible leading and trailing DONT_CARE chunk
        val reserved = FILE_HDR.toLong() + CHUNK_HDR + CHUNK_HDR
        val out = ArrayList<List<Portion>>()
        var cur = ArrayList<Portion>()
        var size = reserved
        var cursor = 0L

        fun flush() {
            out.add(cur)
            cur = ArrayList()
            size = reserved
            cursor = 0L
        }

        for (p in portions) {
            var q: Portion? = p
            while (q != null) {
                val gap = if (cur.isNotEmpty() && q.startBlock > cursor) CHUNK_HDR.toLong() else 0L
                if (q.type == FILL) {
                    if (size + gap + CHUNK_HDR + 4 > limit) {
                        flush()
                        continue
                    }
                    cur.add(q)
                    size += gap + CHUNK_HDR + 4
                    cursor = q.startBlock + q.blocks
                    q = null
                } else {
                    val maxBlocks = (limit - size - gap - CHUNK_HDR) / blk
                    if (maxBlocks <= 0) {
                        if (cur.isEmpty()) throw IOException("max-download-size too small for this image")
                        flush()
                        continue
                    }
                    if (q.blocks <= maxBlocks) {
                        cur.add(q)
                        size += gap + CHUNK_HDR + q.blocks * blk
                        cursor = q.startBlock + q.blocks
                        q = null
                    } else {
                        val headBytes = minOf(q.dataBytes, maxBlocks * blk)
                        val head = Portion(RAW, q.startBlock, maxBlocks, q.fileOffset, headBytes, 0)
                        val tail = Portion(
                            RAW,
                            q.startBlock + maxBlocks,
                            q.blocks - maxBlocks,
                            q.fileOffset + maxBlocks * blk,
                            q.dataBytes - headBytes,
                            0,
                        )
                        cur.add(head)
                        flush()
                        q = tail
                    }
                }
            }
        }
        if (cur.isNotEmpty() || out.isEmpty()) out.add(cur)
        return out
    }

    /** Expands a piece into the exact chunk list (adds DONT_CARE for gaps). */
    fun emitsFor(piece: List<Portion>, totalBlocks: Long): List<Emit> {
        val list = ArrayList<Emit>()
        var cursor = 0L
        for (p in piece) {
            if (p.startBlock > cursor) list.add(Emit(DONT_CARE, p.startBlock - cursor, 0, 0, 0))
            list.add(Emit(p.type, p.blocks, p.fileOffset, p.dataBytes, p.fill))
            cursor = p.startBlock + p.blocks
        }
        if (cursor < totalBlocks) list.add(Emit(DONT_CARE, totalBlocks - cursor, 0, 0, 0))
        return list
    }

    private fun dataSize(e: Emit, blk: Int): Long = when (e.type) {
        RAW -> e.blocks * blk
        FILL -> 4L
        else -> 0L
    }

    fun sizeOf(emits: List<Emit>, blk: Int): Long {
        var s = FILE_HDR.toLong()
        for (e in emits) s += CHUNK_HDR + dataSize(e, blk)
        return s
    }

    fun writePiece(raf: RandomAccessFile, emits: List<Emit>, blk: Int, totalBlocks: Long, sink: DataSink) {
        val hdr = ByteBuffer.allocate(FILE_HDR).order(ByteOrder.LITTLE_ENDIAN)
        hdr.putInt(MAGIC)
        hdr.putShort(1) // major
        hdr.putShort(0) // minor
        hdr.putShort(FILE_HDR.toShort())
        hdr.putShort(CHUNK_HDR.toShort())
        hdr.putInt(blk)
        hdr.putInt(totalBlocks.toInt())
        hdr.putInt(emits.size)
        hdr.putInt(0) // checksum
        sink.write(hdr.array(), 0, FILE_HDR)

        val buf = ByteArray(1 shl 20)
        val zeros = ByteArray(64 * 1024)
        for (e in emits) {
            val ch = ByteBuffer.allocate(CHUNK_HDR).order(ByteOrder.LITTLE_ENDIAN)
            ch.putShort(e.type.toShort())
            ch.putShort(0)
            ch.putInt(e.blocks.toInt())
            ch.putInt((CHUNK_HDR + dataSize(e, blk)).toInt())
            sink.write(ch.array(), 0, CHUNK_HDR)
            when (e.type) {
                RAW -> {
                    raf.seek(e.fileOffset)
                    var left = e.dataBytes
                    while (left > 0) {
                        val n = raf.read(buf, 0, minOf(buf.size.toLong(), left).toInt())
                        if (n <= 0) throw IOException("Unexpected end of image file")
                        sink.write(buf, 0, n)
                        left -= n
                    }
                    var pad = e.blocks * blk - e.dataBytes
                    while (pad > 0) {
                        val n = minOf(zeros.size.toLong(), pad).toInt()
                        sink.write(zeros, 0, n)
                        pad -= n
                    }
                }
                FILL -> {
                    val f = ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN)
                    f.putInt(e.fill)
                    sink.write(f.array(), 0, 4)
                }
            }
        }
    }
}
