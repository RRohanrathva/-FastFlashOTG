package com.example.fastflash

import java.io.BufferedInputStream
import java.io.EOFException
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.io.InputStream
import java.util.zip.GZIPInputStream
import java.util.zip.ZipInputStream

/** One planned fastboot action, parsed from a flash_all script or built by hand. */
class Step(
    val op: String, // flash, erase, set_active, reboot, command, check_product
    val partition: String = "",
    val file: File? = null,
    val argument: String = "",
    val products: List<String> = emptyList(),
) {
    fun describe(): String = when (op) {
        "flash" -> "flash $partition  <-  ${file?.name}"
        "erase" -> "erase $partition"
        "set_active" -> "set_active $argument"
        "reboot" -> if (argument.isEmpty()) "reboot" else "reboot $argument"
        "command" -> argument
        "check_product" -> "check device is: ${products.joinToString(" / ")}"
        else -> op
    }
}

class ParsedScript(val steps: List<Step>, val warnings: List<String>, val missingFiles: List<String>) {
    val wipesData: Boolean
        get() = steps.any {
            (it.op == "erase" || it.op == "flash") && it.partition.lowercase() in setOf("userdata", "metadata")
        }
}

object RomTools {

    // ------------------------------------------------------------------ extraction

    /** Extracts a .zip or .tgz/.tar.gz stream (auto-detected by magic bytes) into [dest]. */
    fun extract(input: InputStream, dest: File, onFile: (String) -> Unit) {
        dest.mkdirs()
        val bin = BufferedInputStream(input, 1 shl 16)
        bin.mark(4)
        val b0 = bin.read()
        val b1 = bin.read()
        bin.reset()
        when {
            b0 == 0x50 && b1 == 0x4B -> extractZip(bin, dest, onFile)
            b0 == 0x1F && b1 == 0x8B -> extractTar(GZIPInputStream(bin, 1 shl 16), dest, onFile)
            else -> throw IOException("Unsupported archive (need .zip or .tgz)")
        }
    }

    private fun safeFile(dest: File, name: String): File? {
        val clean = name.replace('\\', '/').trimStart('/')
        if (clean.isEmpty()) return null
        val f = File(dest, clean)
        val root = dest.canonicalPath + File.separator
        if (!f.canonicalPath.startsWith(root)) throw IOException("Unsafe path in archive: $name")
        return f
    }

    private fun extractZip(input: InputStream, dest: File, onFile: (String) -> Unit) {
        val zin = ZipInputStream(input)
        val buf = ByteArray(1 shl 20)
        while (true) {
            val e = zin.nextEntry ?: break
            if (e.isDirectory) continue
            val f = safeFile(dest, e.name) ?: continue
            f.parentFile?.mkdirs()
            onFile(e.name)
            FileOutputStream(f).use { out ->
                while (true) {
                    val n = zin.read(buf)
                    if (n < 0) break
                    out.write(buf, 0, n)
                }
            }
        }
    }

    private fun readFullyOrEof(input: InputStream, buf: ByteArray, len: Int): Boolean {
        var pos = 0
        while (pos < len) {
            val n = input.read(buf, pos, len - pos)
            if (n < 0) return if (pos == 0) false else throw EOFException("Truncated tar")
            pos += n
        }
        return true
    }

    private fun skipFully(input: InputStream, count: Long) {
        var left = count
        val tmp = ByteArray(1 shl 16)
        while (left > 0) {
            val n = input.read(tmp, 0, minOf(tmp.size.toLong(), left).toInt())
            if (n < 0) throw EOFException("Truncated tar")
            left -= n
        }
    }

    private fun cString(b: ByteArray, off: Int, len: Int): String {
        var end = off
        while (end < off + len && b[end].toInt() != 0) end++
        return String(b, off, end - off, Charsets.UTF_8)
    }

    private fun tarNumber(b: ByteArray, off: Int, len: Int): Long {
        if ((b[off].toInt() and 0x80) != 0) { // GNU base-256 encoding for huge files
            var v = (b[off].toInt() and 0x7F).toLong()
            for (i in 1 until len) v = (v shl 8) or (b[off + i].toLong() and 0xFF)
            return v
        }
        val s = cString(b, off, len).trim()
        return if (s.isEmpty()) 0 else s.toLong(8)
    }

    private fun extractTar(input: InputStream, dest: File, onFile: (String) -> Unit) {
        val hdr = ByteArray(512)
        val buf = ByteArray(1 shl 20)
        var longName: String? = null
        var paxPath: String? = null
        var paxSize: Long? = null
        while (readFullyOrEof(input, hdr, 512)) {
            if (hdr.all { it.toInt() == 0 }) break
            var name = cString(hdr, 0, 100)
            val prefix = cString(hdr, 345, 155)
            if (prefix.isNotEmpty() && cString(hdr, 257, 5) == "ustar") name = "$prefix/$name"
            var size = tarNumber(hdr, 124, 12)
            val type = hdr[156].toInt().toChar()
            val padded = (size + 511) / 512 * 512

            when (type) {
                'L' -> { // GNU long file name
                    val nb = ByteArray(size.toInt())
                    var pos = 0
                    while (pos < nb.size) {
                        val n = input.read(nb, pos, nb.size - pos)
                        if (n < 0) throw EOFException("Truncated tar")
                        pos += n
                    }
                    skipFully(input, padded - size)
                    longName = cString(nb, 0, nb.size)
                    continue
                }
                'x' -> { // PAX extended header: only path and size are used
                    val pb = ByteArray(size.toInt())
                    var pos = 0
                    while (pos < pb.size) {
                        val n = input.read(pb, pos, pb.size - pos)
                        if (n < 0) throw EOFException("Truncated tar")
                        pos += n
                    }
                    skipFully(input, padded - size)
                    for (line in String(pb, Charsets.UTF_8).split('\n')) {
                        val eq = line.indexOf('=')
                        val sp = line.indexOf(' ')
                        if (eq < 0 || sp < 0 || sp > eq) continue
                        val key = line.substring(sp + 1, eq)
                        val value = line.substring(eq + 1)
                        if (key == "path") paxPath = value
                        if (key == "size") paxSize = value.toLongOrNull()
                    }
                    continue
                }
                'g' -> {
                    skipFully(input, padded)
                    continue
                }
            }

            longName?.let { name = it }
            paxPath?.let { name = it }
            paxSize?.let { size = it }
            val paddedFinal = (size + 511) / 512 * 512
            longName = null
            paxPath = null
            paxSize = null

            if (type == '0' || type == '\u0000') {
                val f = safeFile(dest, name)
                if (f != null) {
                    f.parentFile?.mkdirs()
                    onFile(name)
                    FileOutputStream(f).use { out ->
                        var left = size
                        while (left > 0) {
                            val n = input.read(buf, 0, minOf(buf.size.toLong(), left).toInt())
                            if (n < 0) throw EOFException("Truncated tar")
                            out.write(buf, 0, n)
                            left -= n
                        }
                    }
                    skipFully(input, paddedFinal - size)
                } else {
                    skipFully(input, paddedFinal)
                }
            } else {
                skipFully(input, paddedFinal) // directories, links, etc.
            }
        }
    }

    // ------------------------------------------------------------------ scanning

    class Scan(
        val scripts: List<File>,
        val images: List<File>,
        val hasPayload: Boolean,
    )

    fun scan(root: File): Scan {
        val all = root.walkTopDown().filter { it.isFile }.toList()
        val scripts = all.filter { Regex("""flash_all.*\.(sh|bat)""", RegexOption.IGNORE_CASE).matches(it.name) }
            .sortedWith(compareBy({ it.nameWithoutExtension.length }, { it.name }))
        // keep one script per base name, preferring .sh
        val byBase = LinkedHashMap<String, File>()
        for (s in scripts) {
            val key = s.parentFile?.path + "/" + s.nameWithoutExtension
            val existing = byBase[key]
            if (existing == null || (s.extension.equals("sh", true) && !existing.extension.equals("sh", true))) {
                byBase[key] = s
            }
        }
        val images = all.filter { it.extension.equals("img", true) }.sortedBy { it.name }
        val payload = all.any { it.name.equals("payload.bin", true) }
        return Scan(byBase.values.toList(), images, payload)
    }

    // ------------------------------------------------------------------ script parsing

    fun parseScript(script: File, searchRoot: File, allowLock: Boolean = false): ParsedScript {
        val steps = ArrayList<Step>()
        val warnings = ArrayList<String>()
        val missing = ArrayList<String>()
        val scriptDir = script.parentFile ?: searchRoot

        fun resolve(raw: String): File? {
            val p = raw.trim().trim('"', '\'').replace('\\', '/')
            val idx = p.lastIndexOf("images/")
            val rel = if (idx >= 0) p.substring(idx) else p.substringAfterLast('/')
            val a = File(scriptDir, rel)
            if (a.exists()) return a
            val b = File(searchRoot, rel)
            if (b.exists()) return b
            // last resort: find by file name anywhere
            val name = rel.substringAfterLast('/')
            return searchRoot.walkTopDown().firstOrNull { it.isFile && it.name == name }
        }

        for (rawLine in script.readLines()) {
            val line = rawLine.trim()
            if (line.isEmpty()) continue
            val lower = line.lowercase()
            if (!lower.contains("fastboot")) continue
            if (lower.startsWith("#") || lower.startsWith("rem ") || lower.startsWith("::") ||
                lower.startsWith("echo") || lower.startsWith("@echo")
            ) continue

            // product guard:  fastboot getvar product | grep "^product: *munch"
            if (Regex("""getvar\s+product""").containsMatchIn(lower)) {
                val m = Regex("""product:\s*\*([^"'\n]*)""").find(line)
                if (m != null) {
                    val names = m.groupValues[1].split(Regex("[^A-Za-z0-9_]+")).filter { it.isNotEmpty() }
                    if (names.isNotEmpty()) steps.add(Step("check_product", products = names))
                }
                continue
            }

            // keep only the fastboot command itself (cut at shell operators)
            var cmdPart = line
            for (op in listOf("&&", "||", "|", ";", " 2>", " >")) {
                val i = cmdPart.indexOf(op)
                if (i >= 0) cmdPart = cmdPart.substring(0, i)
            }
            val tokens = cmdPart.trim().split(Regex("\\s+")).filter { it.isNotEmpty() }
            val fi = tokens.indexOfFirst { it.lowercase().contains("fastboot") }
            if (fi < 0) continue
            val args = tokens.drop(fi + 1).filter {
                it != "%*" && it != "$*" && it != "$@" && it != "\"$@\"" && !(it.startsWith("-") && it.length > 1)
            }
            if (args.isEmpty()) continue

            when (args[0]) {
                "flash" -> {
                    if (args.size < 3) {
                        warnings.add("Skipped (incomplete): $line")
                    } else {
                        val f = resolve(args[2])
                        if (f == null) {
                            missing.add(args[2])
                        } else {
                            steps.add(Step("flash", partition = args[1], file = f))
                        }
                    }
                }
                "erase" -> if (args.size >= 2) steps.add(Step("erase", partition = args[1]))
                "set_active" -> if (args.size >= 2) steps.add(Step("set_active", argument = args[1]))
                "reboot" -> steps.add(Step("reboot", argument = args.getOrElse(1) { "" }))
                "oem", "flashing" -> {
                    val joined = args.joinToString(" ")
                    val isLock = Regex("""(^|\s)lock(\s|$)""").containsMatchIn(joined)
                    if (isLock && !allowLock) {
                        warnings.add("Skipped for safety (re-locks bootloader): fastboot $joined")
                    } else {
                        steps.add(Step("command", argument = joined))
                    }
                }
                "getvar" -> {} // informational checks are not needed here
                else -> warnings.add("Unsupported command skipped: $line")
            }
        }
        return ParsedScript(steps, warnings, missing)
    }
}
