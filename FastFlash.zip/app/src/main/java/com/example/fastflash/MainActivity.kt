package com.example.fastflash

import android.app.Activity
import android.app.AlertDialog
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.OpenableColumns
import android.text.InputType
import android.util.TypedValue
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.io.IOException
import java.util.concurrent.Executors

class MainActivity : Activity() {

    companion object {
        private const val ACTION_PERMISSION = "com.example.fastflash.USB_PERMISSION"
        private const val REQ_IMAGE = 1
        private const val REQ_ROM = 2
        private const val REQ_BOOT = 3
        private const val ACCENT = 0xFF3F51B5.toInt()
    }

    private lateinit var usb: UsbManager
    private val ui = Handler(Looper.getMainLooper())
    private val worker = Executors.newSingleThreadExecutor()

    private var fb: FastbootDevice? = null
    private var currentUsbName: String? = null

    @Volatile
    private var busy = false

    @Volatile
    private var cancelRequested = false

    private val logBuf = StringBuilder()
    private val actionButtons = ArrayList<Button>()

    private lateinit var statusTv: TextView
    private lateinit var infoTv: TextView
    private lateinit var logTv: TextView
    private lateinit var logScroll: ScrollView
    private lateinit var progressTv: TextView
    private lateinit var progressBar: ProgressBar
    private lateinit var partitionEt: EditText
    private lateinit var cancelBtn: Button

    @Volatile
    private var totalBytes = 0L

    @Volatile
    private var doneBytes = 0L
    private var lastProgressUi = 0L

    @Volatile
    private var bootloaderUnlocked: String? = null

    // ------------------------------------------------------------------ lifecycle

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        usb = getSystemService(Context.USB_SERVICE) as UsbManager
        buildUi()

        val filter = IntentFilter().apply {
            addAction(ACTION_PERMISSION)
            addAction(UsbManager.ACTION_USB_DEVICE_ATTACHED)
            addAction(UsbManager.ACTION_USB_DEVICE_DETACHED)
        }
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(usbReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(usbReceiver, filter)
        }
        log("FastFlash OTG ready. Put the TARGET phone in fastboot mode and connect it with an OTG cable.")
        connect()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (intent.action == UsbManager.ACTION_USB_DEVICE_ATTACHED) connect()
    }

    override fun onDestroy() {
        try {
            unregisterReceiver(usbReceiver)
        } catch (_: Exception) {
        }
        closeDevice()
        super.onDestroy()
    }

    // ------------------------------------------------------------------ USB

    @Suppress("DEPRECATION")
    private fun usbExtra(i: Intent): UsbDevice? =
        if (Build.VERSION.SDK_INT >= 33) {
            i.getParcelableExtra(UsbManager.EXTRA_DEVICE, UsbDevice::class.java)
        } else {
            i.getParcelableExtra(UsbManager.EXTRA_DEVICE)
        }

    private val usbReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            when (intent.action) {
                ACTION_PERMISSION -> {
                    val dev = usbExtra(intent)
                    if (dev != null && intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false)) {
                        openDevice(dev)
                    } else {
                        setStatus("USB permission denied", false)
                    }
                }
                UsbManager.ACTION_USB_DEVICE_ATTACHED -> connect()
                UsbManager.ACTION_USB_DEVICE_DETACHED -> {
                    val dev = usbExtra(intent)
                    if (dev != null && dev.deviceName == currentUsbName) {
                        closeDevice()
                        setStatus("Device disconnected", false)
                        log("Device disconnected.")
                    }
                }
            }
        }
    }

    private fun connect() {
        if (busy) return
        val dev = usb.deviceList.values.firstOrNull { FastbootDevice.findInterface(it) != null }
        if (dev == null) {
            closeDevice()
            setStatus("No fastboot device found", false)
            return
        }
        if (!usb.hasPermission(dev)) {
            setStatus("Waiting for USB permission...", false)
            val flags = if (Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE else 0
            val pi = PendingIntent.getBroadcast(
                this, 0, Intent(ACTION_PERMISSION).setPackage(packageName), flags,
            )
            usb.requestPermission(dev, pi)
            return
        }
        openDevice(dev)
    }

    private fun openDevice(dev: UsbDevice) {
        closeDevice()
        try {
            fb = FastbootDevice.open(usb, dev)
            currentUsbName = dev.deviceName
            setStatus("Connected (fastboot)", true)
            log("Connected to ${dev.deviceName}")
            refreshInfo()
        } catch (e: Exception) {
            setStatus("Error: ${e.message}", false)
            log("ERROR: ${e.message}")
        }
    }

    private fun closeDevice() {
        fb?.close()
        fb = null
        currentUsbName = null
        bootloaderUnlocked = null
        ui.post { infoTv.text = "-" }
    }

    private fun refreshInfo() {
        withDevice("Read device info") { dev ->
            val names = listOf(
                "product", "variant", "serialno", "current-slot", "slot-count", "unlocked",
                "secure", "is-userspace", "max-download-size", "version-bootloader", "version-baseband",
            )
            val sb = StringBuilder()
            for (n in names) {
                val v = dev.getvar(n)
                if (v != null) {
                    sb.append(n).append(": ").append(v).append('\n')
                    if (n == "unlocked") bootloaderUnlocked = v.trim()
                }
            }
            ui.post { infoTv.text = if (sb.isEmpty()) "(no data)" else sb.toString().trimEnd() }
        }
    }

    // ------------------------------------------------------------------ job helpers

    private fun launch(title: String, block: () -> Unit) {
        if (busy) {
            toast("Another task is running")
            return
        }
        busy = true
        cancelRequested = false
        doneBytes = 0
        totalBytes = 0
        updateButtons()
        worker.execute {
            try {
                log("== $title")
                block()
                log("OK: $title finished")
            } catch (t: Throwable) {
                log("ERROR: ${t.message ?: t.javaClass.simpleName}")
            } finally {
                fb?.onBytes = null
                busy = false
                ui.post {
                    updateButtons()
                    progressBar.progress = 0
                    progressTv.text = "Idle"
                }
            }
        }
    }

    private fun withDevice(title: String, block: (FastbootDevice) -> Unit) {
        val d = fb
        if (d == null) {
            toast("Connect a fastboot device first")
            return
        }
        launch(title) { block(d) }
    }

    private fun updateButtons() {
        ui.post {
            for (b in actionButtons) b.isEnabled = !busy
            cancelBtn.isEnabled = busy
        }
    }

    private fun addBytes(n: Long) {
        doneBytes += n
        val now = SystemClock.uptimeMillis()
        if (now - lastProgressUi > 250) {
            lastProgressUi = now
            val d = doneBytes
            val t = totalBytes
            ui.post { renderProgress(d, t) }
        }
    }

    private fun renderProgress(done: Long, total: Long) {
        val pct = if (total > 0) minOf(100L, done * 100 / total).toInt() else 0
        progressBar.progress = pct * 10
        progressTv.text = "${done / 1048576} / ${total / 1048576} MB ($pct%)"
    }

    private fun workDir(): File = externalCacheDir ?: cacheDir

    private fun log(s: String) {
        val text = synchronized(logBuf) {
            logBuf.append(s).append('\n')
            if (logBuf.length > 200_000) logBuf.delete(0, 50_000)
            logBuf.toString()
        }
        ui.post {
            logTv.text = text
            logScroll.post { logScroll.fullScroll(View.FOCUS_DOWN) }
        }
    }

    private fun setStatus(s: String, ok: Boolean) {
        ui.post {
            statusTv.text = s
            statusTv.setTextColor(if (ok) 0xFF2E7D32.toInt() else 0xFFC62828.toInt())
        }
    }

    private fun toast(s: String) = ui.post { Toast.makeText(this, s, Toast.LENGTH_SHORT).show() }

    private fun confirm(title: String, message: String, positive: String = "Continue", onYes: () -> Unit) {
        ui.post {
            AlertDialog.Builder(this)
                .setTitle(title)
                .setMessage(message)
                .setPositiveButton(positive) { _, _ -> onYes() }
                .setNegativeButton("Cancel", null)
                .show()
        }
    }

    private fun askText(title: String, hint: String, onOk: (String) -> Unit) {
        val et = EditText(this).apply {
            this.hint = hint
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            setSingleLine(true)
        }
        val pad = dp(20)
        val box = LinearLayout(this).apply {
            setPadding(pad, dp(8), pad, 0)
            addView(et, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }
        AlertDialog.Builder(this)
            .setTitle(title)
            .setView(box)
            .setPositiveButton("OK") { _, _ ->
                val t = et.text.toString().trim()
                if (t.isNotEmpty()) onOk(t)
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // ------------------------------------------------------------------ file picking

    private fun pickFile(code: Int) {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
        }
        startActivityForResult(i, code)
    }

    @Suppress("DEPRECATION", "OVERRIDE_DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val uri = data?.data
        if (resultCode != RESULT_OK || uri == null) return
        when (requestCode) {
            REQ_IMAGE -> onImagePicked(uri)
            REQ_ROM -> onRomPicked(uri)
            REQ_BOOT -> onBootPicked(uri)
        }
    }

    private fun displayName(uri: Uri): String {
        try {
            contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) return c.getString(0) ?: "file"
            }
        } catch (_: Exception) {
        }
        return uri.lastPathSegment ?: "file"
    }

    private fun copyToCache(uri: Uri, name: String): File {
        val out = File(workDir(), name)
        log("Copying $name to temporary storage...")
        val input = contentResolver.openInputStream(uri) ?: throw IOException("Cannot open file")
        input.use { ins ->
            out.outputStream().use { os ->
                val buf = ByteArray(1 shl 20)
                while (true) {
                    val n = ins.read(buf)
                    if (n < 0) break
                    os.write(buf, 0, n)
                }
            }
        }
        return out
    }

    // ------------------------------------------------------------------ single image

    private fun unlockedWarning(): String =
        if (bootloaderUnlocked == "no") "\n\nWARNING: this phone reports a LOCKED bootloader. Flashing will most likely fail." else ""

    private fun onImagePicked(uri: Uri) {
        val part = partitionEt.text.toString().trim()
        if (part.isEmpty()) {
            toast("Type the partition name first (e.g. boot)")
            return
        }
        val name = displayName(uri)
        confirm(
            "Flash image",
            "Flash \"$name\" to partition \"$part\" on the connected phone?\n\nA wrong image can brick the phone." + unlockedWarning(),
            "Flash",
        ) {
            withDevice("Flash $part") { dev ->
                val f = copyToCache(uri, "picked_image.bin")
                try {
                    flashOne(dev, part, f)
                } finally {
                    f.delete()
                }
            }
        }
    }

    private fun flashOne(dev: FastbootDevice, part: String, file: File) {
        val max = dev.maxDownloadSize()
        val real = dev.resolvePartition(part)
        totalBytes = file.length()
        doneBytes = 0
        dev.onBytes = { addBytes(it) }
        log("flash $real (${file.length()} bytes, max-download-size $max)")
        dev.flashFile(real, file, max) { log(it) }
    }

    private fun onBootPicked(uri: Uri) {
        val name = displayName(uri)
        confirm("Boot image once", "Boot \"$name\" temporarily without flashing it?", "Boot") {
            withDevice("Boot image") { dev ->
                val f = copyToCache(uri, "boot_once.img")
                try {
                    val max = dev.maxDownloadSize()
                    if (f.length() > max) throw FastbootException("Image is larger than max-download-size ($max)")
                    totalBytes = f.length()
                    dev.onBytes = { addBytes(it) }
                    dev.downloadWholeFile(f)
                    dev.send("boot", 60_000) { log("  device: $it") }
                    ui.post {
                        closeDevice()
                        setStatus("Device is booting the image", false)
                    }
                } finally {
                    f.delete()
                }
            }
        }
    }

    // ------------------------------------------------------------------ ROM flashing

    private fun onRomPicked(uri: Uri) {
        val name = displayName(uri)
        launch("Extract $name") {
            val dir = File(workDir(), "rom")
            dir.deleteRecursively()
            val input = contentResolver.openInputStream(uri) ?: throw IOException("Cannot open file")
            input.use { RomTools.extract(it, dir) { n -> log("  extracting $n") } }
            val scan = RomTools.scan(dir)
            ui.post { showRomChoices(dir, scan) }
        }
    }

    private fun describeScript(f: File): String {
        val n = f.name.lowercase()
        val hint = when {
            n.contains("lock") -> "re-lock step is skipped for safety"
            n.contains("except") -> "keeps your data"
            else -> "WIPES all data"
        }
        return "${f.name}\n($hint)"
    }

    private fun showRomChoices(dir: File, scan: RomTools.Scan) {
        if (scan.scripts.isEmpty() && scan.images.isEmpty()) {
            val msg = if (scan.hasPayload) {
                "This is an OTA package (payload.bin). It is not supported here. Download the fastboot ROM (.tgz / .zip with flash_all script) instead."
            } else {
                "No flash script or .img files found in this archive."
            }
            AlertDialog.Builder(this).setTitle("Nothing to flash").setMessage(msg).setPositiveButton("OK", null).show()
            return
        }
        if (scan.scripts.isNotEmpty()) {
            val labels = scan.scripts.map { describeScript(it) }.toTypedArray()
            AlertDialog.Builder(this)
                .setTitle("Choose flash script")
                .setItems(labels) { _, which -> onScriptChosen(dir, scan.scripts[which]) }
                .setNegativeButton("Cancel", null)
                .show()
        } else {
            val imgs = scan.images
            val names = imgs.map { it.name }.toTypedArray()
            val checked = BooleanArray(imgs.size) { !imgs[it].name.contains("empty", true) }
            AlertDialog.Builder(this)
                .setTitle("Images to flash (partition = file name)")
                .setMultiChoiceItems(names, checked) { _, which, isChecked -> checked[which] = isChecked }
                .setPositiveButton("Next") { _, _ ->
                    val steps = imgs.indices.filter { checked[it] }
                        .map { Step("flash", partition = imgs[it].nameWithoutExtension, file = imgs[it]) }
                    if (steps.isEmpty()) toast("Nothing selected") else showSummary(steps, emptyList())
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
    }

    private fun onScriptChosen(dir: File, script: File) {
        val parsed = try {
            RomTools.parseScript(script, dir)
        } catch (e: Exception) {
            toast("Cannot read script: ${e.message}")
            return
        }
        if (parsed.missingFiles.isNotEmpty()) {
            AlertDialog.Builder(this)
                .setTitle("Files missing in ROM")
                .setMessage("The script needs files that are not in the archive:\n\n" + parsed.missingFiles.joinToString("\n"))
                .setPositiveButton("OK", null)
                .show()
            return
        }
        if (parsed.steps.none { it.op == "flash" }) {
            toast("No flash steps found in script")
            return
        }
        showSummary(parsed.steps, parsed.warnings)
    }

    private fun showSummary(steps: List<Step>, warnings: List<String>) {
        val parsed = ParsedScript(steps, warnings, emptyList())
        val sb = StringBuilder()
        sb.append("${steps.count { it.op == "flash" }} flash step(s), ${steps.count { it.op == "erase" }} erase step(s)\n")
        sb.append("User data wiped: ").append(if (parsed.wipesData) "YES" else "no").append('\n')
        if (bootloaderUnlocked == "no") sb.append("WARNING: bootloader is LOCKED - flashing will fail.\n")
        if (warnings.isNotEmpty()) sb.append("\nNotes:\n").append(warnings.joinToString("\n")).append('\n')
        sb.append("\nSteps:\n")
        for (s in steps) sb.append("- ").append(s.describe()).append('\n')
        confirm("Start flashing?", sb.toString(), "Start") {
            withDevice("Flash ROM") { dev -> runSteps(dev, steps) }
        }
    }

    private fun runSteps(dev: FastbootDevice, steps: List<Step>) {
        val max = dev.maxDownloadSize()
        totalBytes = steps.filter { it.op == "flash" }.sumOf { it.file?.length() ?: 0L }
        doneBytes = 0
        dev.onBytes = { addBytes(it) }
        for ((i, s) in steps.withIndex()) {
            if (cancelRequested) throw FastbootException("Cancelled by user")
            log("[${i + 1}/${steps.size}] ${s.describe()}")
            when (s.op) {
                "check_product" -> {
                    val p = dev.getvar("product")?.trim().orEmpty()
                    if (s.products.none { it.equals(p, true) }) {
                        throw FastbootException("Wrong ROM for this phone: device is '$p', ROM is for ${s.products.joinToString("/")}")
                    }
                }
                "flash" -> {
                    val part = dev.resolvePartition(s.partition)
                    dev.flashFile(part, s.file!!, max) { log(it) }
                }
                "erase" -> dev.send("erase:" + dev.resolvePartition(s.partition), 300_000) { log("  device: $it") }
                "set_active" -> dev.send("set_active:" + s.argument, 30_000)
                "reboot" -> {
                    dev.send(if (s.argument.isEmpty()) "reboot" else "reboot-" + s.argument, 30_000)
                    ui.post {
                        closeDevice()
                        setStatus("Device is rebooting", false)
                    }
                    return
                }
                "command" -> dev.send(s.argument, 120_000) { log("  device: $it") }
            }
        }
    }

    // ------------------------------------------------------------------ tools

    private fun rebootTo(target: String) {
        withDevice("Reboot ${target.ifEmpty { "system" }}") { dev ->
            dev.send(if (target.isEmpty()) "reboot" else "reboot-$target", 30_000)
            ui.post {
                closeDevice()
                setStatus("Device is rebooting - reconnect when needed", false)
            }
        }
    }

    private fun setSlot(slot: String) {
        withDevice("Set active slot $slot") { it.send("set_active:$slot", 30_000) }
    }

    private fun erasePartition() {
        askText("Erase partition", "partition name (e.g. userdata)") { part ->
            confirm(
                "Erase \"$part\"?",
                "This permanently deletes the contents of partition \"$part\". Erasing the wrong partition can brick the phone." + unlockedWarning(),
                "Erase",
            ) {
                withDevice("Erase $part") { dev ->
                    dev.send("erase:" + dev.resolvePartition(part), 300_000) { log("  device: $it") }
                }
            }
        }
    }

    private fun customCommand() {
        askText("Fastboot command", "e.g. getvar:product  or  oem device-info") { cmd ->
            if (Regex("""(^|[\s:])lock(\s|$)""").containsMatchIn(cmd.lowercase())) {
                toast("Re-locking the bootloader is blocked here (can brick the phone).")
                return@askText
            }
            withDevice("Command: $cmd") { dev ->
                val r = dev.send(cmd, 120_000) { log("  device: $it") }
                if (r.isNotEmpty()) log("  result: $r")
            }
        }
    }

    private fun allVars() {
        withDevice("All variables") { dev -> dev.getAllVars().forEach { log("  $it") } }
    }

    private fun clearCache() {
        if (busy) {
            toast("Wait for the running task")
            return
        }
        val dir = workDir()
        var freed = 0L
        dir.listFiles()?.forEach {
            freed += it.walkTopDown().filter { f -> f.isFile }.sumOf { f -> f.length() }
            it.deleteRecursively()
        }
        log("Cleared temporary files (${freed / 1048576} MB).")
    }

    // ------------------------------------------------------------------ UI

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

    private fun buildUi() {
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(20), dp(16), dp(24))
        }
        val root = ScrollView(this).apply {
            setBackgroundColor(0xFFF3F4F8.toInt())
            isFillViewport = true
            addView(content)
        }
        setContentView(root)

        content.addView(text("FastFlash OTG", 26f, bold = true, color = ACCENT))
        content.addView(text("Flash a Xiaomi / Android phone in fastboot mode from this phone over a USB-OTG cable.", 13f, color = 0xFF555B6E.toInt()))
        content.addView(spacer(12))

        // connection
        val cConn = card("1. Connection")
        statusTv = text("No fastboot device found", 15f, bold = true, color = 0xFFC62828.toInt())
        infoTv = text("-", 12f, mono = true, color = 0xFF333333.toInt())
        cConn.addView(statusTv)
        cConn.addView(infoTv)
        cConn.addView(row(
            actionButton("Connect") { connect() },
            actionButton("Refresh info") { refreshInfo() },
        ))
        content.addView(cConn)

        // single image
        val cImg = card("2. Flash one image")
        partitionEt = EditText(this).apply {
            hint = "Partition name, e.g. boot, recovery, vendor_boot"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            setSingleLine(true)
        }
        cImg.addView(partitionEt)
        cImg.addView(actionButton("Choose image and flash") {
            if (partitionEt.text.toString().trim().isEmpty()) toast("Type the partition name first") else pickFile(REQ_IMAGE)
        })
        content.addView(cImg)

        // ROM
        val cRom = card("3. Flash a fastboot ROM")
        cRom.addView(text("Pick the ROM file (.zip or .tgz) containing flash_all script and images/. It is extracted to temporary storage first - keep enough free space.", 12f, color = 0xFF555B6E.toInt()))
        cRom.addView(actionButton("Choose ROM (.zip / .tgz)") { pickFile(REQ_ROM) })
        content.addView(cRom)

        // tools
        val cTools = card("4. Tools")
        cTools.addView(row(
            actionButton("Reboot system") { rebootTo("") },
            actionButton("Reboot bootloader") { rebootTo("bootloader") },
        ))
        cTools.addView(row(
            actionButton("Reboot recovery") { rebootTo("recovery") },
            actionButton("Reboot fastbootd") { rebootTo("fastboot") },
        ))
        cTools.addView(row(
            actionButton("Set slot A") { setSlot("a") },
            actionButton("Set slot B") { setSlot("b") },
        ))
        cTools.addView(row(
            actionButton("Erase partition") { erasePartition() },
            actionButton("Boot image once") { pickFile(REQ_BOOT) },
        ))
        cTools.addView(row(
            actionButton("Custom command") { customCommand() },
            actionButton("All variables") { allVars() },
        ))
        cTools.addView(actionButton("Clear temporary files") { clearCache() })
        content.addView(cTools)

        // progress
        val cProg = card("Progress")
        progressBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 1000 }
        progressTv = text("Idle", 12f, color = 0xFF333333.toInt())
        cancelBtn = Button(this).apply {
            this.text = "Cancel after current step"
            isAllCaps = false
            isEnabled = false
            setOnClickListener {
                cancelRequested = true
                log("Cancel requested - stopping after the current step.")
            }
        }
        cProg.addView(progressBar)
        cProg.addView(progressTv)
        cProg.addView(cancelBtn)
        content.addView(cProg)

        // log
        val cLog = card("Log")
        logTv = text("", 11f, mono = true, color = 0xFF222222.toInt()).apply { setTextIsSelectable(true) }
        logScroll = ScrollView(this).apply {
            addView(logTv)
            setOnTouchListener { v, _ ->
                v.parent.requestDisallowInterceptTouchEvent(true)
                false
            }
        }
        cLog.addView(logScroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(260)))
        cLog.addView(row(
            plainButton("Copy log") {
                val text = synchronized(logBuf) { logBuf.toString() }
                (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager)
                    .setPrimaryClip(ClipData.newPlainText("FastFlash log", text))
                toast("Log copied")
            },
            plainButton("Clear log") {
                synchronized(logBuf) { logBuf.setLength(0) }
                logTv.text = ""
            },
        ))
        content.addView(cLog)
    }

    private fun card(title: String): LinearLayout {
        val c = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(12), dp(14), dp(14))
            background = GradientDrawable().apply {
                setColor(Color.WHITE)
                cornerRadius = dp(14).toFloat()
                setStroke(dp(1), 0xFFE0E3EA.toInt())
            }
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT,
            ).apply { bottomMargin = dp(12) }
        }
        c.addView(text(title, 16f, bold = true, color = 0xFF1B1F3B.toInt()))
        return c
    }

    private fun text(
        s: String,
        sizeSp: Float,
        bold: Boolean = false,
        mono: Boolean = false,
        color: Int = Color.BLACK,
    ): TextView = TextView(this).apply {
        text = s
        setTextSize(TypedValue.COMPLEX_UNIT_SP, sizeSp)
        setTextColor(color)
        if (mono) typeface = Typeface.MONOSPACE else if (bold) typeface = Typeface.DEFAULT_BOLD
        setPadding(0, dp(3), 0, dp(3))
    }

    private fun spacer(h: Int): View = View(this).apply {
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(h))
    }

    private fun plainButton(label: String, onClick: () -> Unit): Button = Button(this).apply {
        text = label
        isAllCaps = false
        setOnClickListener { onClick() }
    }

    private fun actionButton(label: String, onClick: () -> Unit): Button {
        val b = plainButton(label, onClick)
        actionButtons.add(b)
        return b
    }

    private fun row(vararg buttons: Button): LinearLayout {
        val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for (b in buttons) {
            r.addView(b, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        }
        return r
    }
}
