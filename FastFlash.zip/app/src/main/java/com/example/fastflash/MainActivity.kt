package com.example.fastflash

import android.app.Activity
import android.app.AlertDialog
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.OpenableColumns
import android.text.InputType
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.io.IOException
import java.util.concurrent.Executors

class MainActivity : Activity() {

    companion object {
        private const val ACTION_PERMISSION = "com.example.fastflash.USB_PERMISSION"
        private const val REQ_IMAGE = 1
        private const val REQ_ROM = 2
        private const val REQ_BOOT = 3

        private const val BG = 0xFF0E1117.toInt()
        private const val SURFACE = 0xFF181C27.toInt()
        private const val SURFACE2 = 0xFF262C3D.toInt()
        private const val TEXT = 0xFFE6E9F2.toInt()
        private const val MUTED = 0xFF8B93A7.toInt()
        private const val ACCENT = 0xFF5C7CFA.toInt()
        private const val GREEN = 0xFF3DDC84.toInt()
        private const val RED = 0xFFFF5C6C.toInt()
        private const val RED_DARK = 0xFFB3263A.toInt()
        private const val AMBER = 0xFFFFB84D.toInt()

        private val MODE_TITLES = arrayOf("Clean all", "Save user data", "Clean all and lock")
        private val MODE_DESCS = arrayOf(
            "Erases ALL data, including internal storage. Cleanest result.",
            "Keeps your apps and files. Use it when updating the same ROM.",
            "Erases all data and RE-LOCKS the bootloader. Only use the official ROM made for this exact phone, a wrong ROM can brick it.",
        )
    }

    private lateinit var usb: UsbManager
    private val ui = Handler(Looper.getMainLooper())
    private val worker = Executors.newSingleThreadExecutor()

    private var fb: FastbootDevice? = null
    private var currentUsbName: String? = null

    @Volatile
    private var busy = false

    @Volatile
    private var cancelRequested = false

    private val logBuf = StringBuilder()
    private val actionButtons = ArrayList<Button>()

    // header / shared
    private lateinit var statusTv: TextView
    private lateinit var progressPanel: LinearLayout
    private lateinit var progressBar: ProgressBar
    private lateinit var progressTv: TextView
    private lateinit var cancelBtn: Button
    private val pages = ArrayList<View>()
    private val navItems = ArrayList<TextView>()

    // device page
    private lateinit var infoTv: TextView

    // rom page
    private lateinit var romNameTv: TextView
    private lateinit var romStateTv: TextView
    private lateinit var romOptionsCard: LinearLayout
    private lateinit var modeGroup: RadioGroup
    private val modeButtons = ArrayList<RadioButton>()
    private lateinit var imagesBox: LinearLayout
    private lateinit var stepsTv: TextView
    private lateinit var flashRomBtn: Button
    private var romDir: File? = null
    private var romScan: RomTools.Scan? = null
    private var modeScripts: Array<File?> = arrayOfNulls(3)
    private var selectedMode = 0
    private var currentParsed: ParsedScript? = null
    private var romReady = false
    private val imageChecks = ArrayList<Pair<CheckBox, File>>()

    // image page
    private lateinit var partitionEt: EditText

    // commands page
    private lateinit var cmdEt: EditText
    private lateinit var varEt: EditText
    private lateinit var eraseEt: EditText
    private lateinit var cmdOutTv: TextView
    private val cmdOutBuf = StringBuilder()

    // log page
    private lateinit var logTv: TextView
    private lateinit var logScroll: ScrollView

    @Volatile
    private var totalBytes = 0L

    @Volatile
    private var doneBytes = 0L
    private var lastProgressUi = 0L

    @Volatile
    private var bootloaderUnlocked: String? = null

    // ------------------------------------------------------------------ lifecycle

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.statusBarColor = 0xFF1E2A5A.toInt()
        window.navigationBarColor = SURFACE
        usb = getSystemService(Context.USB_SERVICE) as UsbManager
        buildUi()

        val filter = IntentFilter().apply {
            addAction(ACTION_PERMISSION)
            addAction(UsbManager.ACTION_USB_DEVICE_ATTACHED)
            addAction(UsbManager.ACTION_USB_DEVICE_DETACHED)
        }
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(usbReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(usbReceiver, filter)
        }
        log("FastFlash OTG ready. Put the TARGET phone in fastboot mode and connect it with an OTG cable.")
        connect()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (intent.action == UsbManager.ACTION_USB_DEVICE_ATTACHED) connect()
    }

    override fun onDestroy() {
        try {
            unregisterReceiver(usbReceiver)
        } catch (_: Exception) {
        }
        closeDevice()
        super.onDestroy()
    }

    // ------------------------------------------------------------------ USB

    @Suppress("DEPRECATION")
    private fun usbExtra(i: Intent): UsbDevice? =
        if (Build.VERSION.SDK_INT >= 33) {
            i.getParcelableExtra(UsbManager.EXTRA_DEVICE, UsbDevice::class.java)
        } else {
            i.getParcelableExtra(UsbManager.EXTRA_DEVICE)
        }

    private val usbReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            when (intent.action) {
                ACTION_PERMISSION -> {
                    val dev = usbExtra(intent)
                    if (dev != null && intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false)) {
                        openDevice(dev)
                    } else {
                        setStatus("USB permission denied", false)
                    }
                }
                UsbManager.ACTION_USB_DEVICE_ATTACHED -> connect()
                UsbManager.ACTION_USB_DEVICE_DETACHED -> {
                    val dev = usbExtra(intent)
                    if (dev != null && dev.deviceName == currentUsbName) {
                        closeDevice()
                        setStatus("Device disconnected", false)
                        log("Device disconnected.")
                    }
                }
            }
        }
    }

    private fun connect() {
        if (busy) return
        val dev = usb.deviceList.values.firstOrNull { FastbootDevice.findInterface(it) != null }
        if (dev == null) {
            closeDevice()
            setStatus("No fastboot device found", false)
            return
        }
        if (!usb.hasPermission(dev)) {
            setStatus("Waiting for USB permission...", false)
            val flags = if (Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE else 0
            val pi = PendingIntent.getBroadcast(
                this, 0, Intent(ACTION_PERMISSION).setPackage(packageName), flags,
            )
            usb.requestPermission(dev, pi)
            return
        }
        openDevice(dev)
    }

    private fun openDevice(dev: UsbDevice) {
        closeDevice()
        try {
            fb = FastbootDevice.open(usb, dev)
            currentUsbName = dev.deviceName
            setStatus("Connected (fastboot)", true)
            log("Connected to ${dev.deviceName}")
            refreshInfo()
        } catch (e: Exception) {
            setStatus("Error: ${e.message}", false)
            log("ERROR: ${e.message}")
        }
    }

    private fun closeDevice() {
        fb?.close()
        fb = null
        currentUsbName = null
        bootloaderUnlocked = null
        ui.post { infoTv.text = "No data. Connect a phone in fastboot mode." }
    }

    private fun refreshInfo() {
        withDevice("Read device info") { dev ->
            val names = listOf(
                "product", "variant", "serialno", "current-slot", "slot-count", "unlocked",
                "secure", "is-userspace", "max-download-size", "version-bootloader", "version-baseband",
            )
            val sb = StringBuilder()
            var product = ""
            for (n in names) {
                val v = dev.getvar(n)
                if (v != null) {
                    sb.append(n).append(": ").append(v).append('\n')
                    if (n == "unlocked") bootloaderUnlocked = v.trim()
                    if (n == "product") product = v.trim()
                }
            }
            ui.post { infoTv.text = if (sb.isEmpty()) "(no data)" else sb.toString().trimEnd() }
            if (product.isNotEmpty()) {
                val lock = if (bootloaderUnlocked == "yes") "unlocked" else if (bootloaderUnlocked == "no") "LOCKED" else "?"
                setStatus("Connected: $product ($lock)", bootloaderUnlocked != "no")
            }
        }
    }

    // ------------------------------------------------------------------ job helpers

    private fun launch(title: String, indeterminate: Boolean = false, block: () -> Unit) {
        if (busy) {
            toast("Another task is running")
            return
        }
        busy = true
        cancelRequested = false
        doneBytes = 0
        totalBytes = 0
        updateButtons()
        ui.post {
            progressPanel.visibility = View.VISIBLE
            progressBar.isIndeterminate = indeterminate
            progressBar.progress = 0
            progressTv.text = title
        }
        worker.execute {
            try {
                log("== $title")
                block()
                log("OK: $title finished")
            } catch (t: Throwable) {
                log("ERROR: ${t.message ?: t.javaClass.simpleName}")
            } finally {
                fb?.onBytes = null
                busy = false
                ui.post {
                    updateButtons()
                    progressBar.isIndeterminate = false
                    progressPanel.visibility = View.GONE
                }
            }
        }
    }

    private fun withDevice(title: String, block: (FastbootDevice) -> Unit) {
        val d = fb
        if (d == null) {
            toast("Connect a fastboot device first")
            return
        }
        launch(title) { block(d) }
    }

    private fun updateButtons() {
        ui.post {
            for (b in actionButtons) {
                b.isEnabled = !busy
                b.alpha = if (b.isEnabled) 1f else 0.4f
            }
            val flashOk = !busy && romReady
            flashRomBtn.isEnabled = flashOk
            flashRomBtn.alpha = if (flashOk) 1f else 0.4f
            cancelBtn.isEnabled = busy
        }
    }

    private fun addBytes(n: Long) {
        doneBytes += n
        val now = SystemClock.uptimeMillis()
        if (now - lastProgressUi > 250) {
            lastProgressUi = now
            val d = doneBytes
            val t = totalBytes
            ui.post { renderProgress(d, t) }
        }
    }

    private fun renderProgress(done: Long, total: Long) {
        val pct = if (total > 0) minOf(100L, done * 100 / total).toInt() else 0
        progressBar.progress = pct * 10
        progressTv.text = "Sending data: ${done / 1048576} / ${total / 1048576} MB ($pct%)"
    }

    private fun setProgressText(s: String) {
        ui.post { progressTv.text = s }
    }

    private fun workDir(): File = externalCacheDir ?: cacheDir

    private fun log(s: String) {
        val text = synchronized(logBuf) {
            logBuf.append(s).append('\n')
            if (logBuf.length > 200_000) logBuf.delete(0, 50_000)
            logBuf.toString()
        }
        ui.post {
            logTv.text = text
            logScroll.post { logScroll.fullScroll(View.FOCUS_DOWN) }
        }
    }

    private fun cmdOut(s: String) {
        val text = synchronized(cmdOutBuf) {
            cmdOutBuf.append(s).append('\n')
            if (cmdOutBuf.length > 100_000) cmdOutBuf.delete(0, 30_000)
            cmdOutBuf.toString()
        }
        ui.post { cmdOutTv.text = text }
    }

    private fun setStatus(s: String, ok: Boolean) {
        ui.post {
            statusTv.text = "●  $s"
            statusTv.setTextColor(if (ok) GREEN else RED)
        }
    }

    private fun toast(s: String) {
        ui.post { Toast.makeText(this, s, Toast.LENGTH_SHORT).show() }
    }

    private fun confirm(title: String, message: String, positive: String = "Continue", onYes: () -> Unit) {
        ui.post {
            AlertDialog.Builder(this)
                .setTitle(title)
                .setMessage(message)
                .setPositiveButton(positive) { _, _ -> onYes() }
                .setNegativeButton("Cancel", null)
                .show()
        }
    }

    private fun askText(title: String, hint: String, onOk: (String) -> Unit) {
        val et = EditText(this).apply {
            this.hint = hint
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            setSingleLine(true)
        }
        val pad = dp(20)
        val box = LinearLayout(this).apply {
            setPadding(pad, dp(8), pad, 0)
            addView(et, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }
        AlertDialog.Builder(this)
            .setTitle(title)
            .setView(box)
            .setPositiveButton("OK") { _, _ ->
                val t = et.text.toString().trim()
                if (t.isNotEmpty()) onOk(t)
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun unlockedWarning(): String =
        if (bootloaderUnlocked == "no") "\n\nWARNING: this phone reports a LOCKED bootloader. Flashing will most likely fail." else ""

    // ------------------------------------------------------------------ file picking

    private fun pickFile(code: Int) {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
        }
        startActivityForResult(i, code)
    }

    @Suppress("DEPRECATION", "OVERRIDE_DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val uri = data?.data
        if (resultCode != RESULT_OK || uri == null) return
        when (requestCode) {
            REQ_IMAGE -> onImagePicked(uri)
            REQ_ROM -> onRomPicked(uri)
            REQ_BOOT -> onBootPicked(uri)
        }
    }

    private fun displayName(uri: Uri): String {
        try {
            contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) return c.getString(0) ?: "file"
            }
        } catch (_: Exception) {
        }
        return uri.lastPathSegment ?: "file"
    }

    private fun copyToCache(uri: Uri, name: String): File {
        val out = File(workDir(), name)
        log("Copying $name to temporary storage...")
        val input = contentResolver.openInputStream(uri) ?: throw IOException("Cannot open file")
        input.use { ins ->
            out.outputStream().use { os ->
                val buf = ByteArray(1 shl 20)
                while (true) {
                    val n = ins.read(buf)
                    if (n < 0) break
                    os.write(buf, 0, n)
                }
            }
        }
        return out
    }

    // ------------------------------------------------------------------ single image

    private fun onImagePicked(uri: Uri) {
        val part = partitionEt.text.toString().trim()
        if (part.isEmpty()) {
            toast("Type the partition name first (e.g. boot)")
            return
        }
        val name = displayName(uri)
        confirm(
            "Flash image",
            "Flash \"$name\" to partition \"$part\" on the connected phone?\n\nA wrong image can brick the phone." + unlockedWarning(),
            "Flash",
        ) {
            withDevice("Flash $part") { dev ->
                val f = copyToCache(uri, "picked_image.bin")
                try {
                    val max = dev.maxDownloadSize()
                    val real = dev.resolvePartition(part)
                    totalBytes = f.length()
                    dev.onBytes = { addBytes(it) }
                    log("flash $real (${f.length()} bytes, max-download-size $max)")
                    dev.flashFile(real, f, max) { log(it) }
                } finally {
                    f.delete()
                }
            }
        }
    }

    private fun onBootPicked(uri: Uri) {
        val name = displayName(uri)
        confirm("Boot image once", "Boot \"$name\" temporarily without flashing it?", "Boot") {
            withDevice("Boot image") { dev ->
                val f = copyToCache(uri, "boot_once.img")
                try {
                    val max = dev.maxDownloadSize()
                    if (f.length() > max) throw FastbootException("Image is larger than max-download-size ($max)")
                    totalBytes = f.length()
                    dev.onBytes = { addBytes(it) }
                    dev.downloadWholeFile(f)
                    dev.send("boot", 60_000) { log("  device: $it") }
                    ui.post {
                        closeDevice()
                        setStatus("Device is booting the image", false)
                    }
                } finally {
                    f.delete()
                }
            }
        }
    }

    // ------------------------------------------------------------------ ROM flashing

    private fun onRomPicked(uri: Uri) {
        val name = displayName(uri)
        romReady = false
        romDir = null
        romScan = null
        ui.post {
            romNameTv.text = name
            romStateTv.text = "Extracting... please wait"
            romStateTv.setTextColor(AMBER)
            romOptionsCard.visibility = View.GONE
        }
        launch("Extracting $name", true) {
            val dir = File(workDir(), "rom")
            dir.deleteRecursively()
            val input = contentResolver.openInputStream(uri) ?: throw IOException("Cannot open file")
            try {
                input.use {
                    RomTools.extract(it, dir) { n ->
                        log("  extracting $n")
                        setProgressText("Extracting: $n")
                    }
                }
            } catch (e: Throwable) {
                ui.post {
                    romStateTv.text = "Extraction failed: ${e.message}"
                    romStateTv.setTextColor(RED)
                }
                throw e
            }
            val scan = RomTools.scan(dir)
            ui.post {
                romDir = dir
                romScan = scan
                onRomExtracted(scan)
            }
        }
    }

    private fun findModeScripts(scripts: List<File>): Array<File?> {
        val clean = scripts.firstOrNull { it.nameWithoutExtension.equals("flash_all", true) }
        val save = scripts.firstOrNull { it.name.contains("except", true) && !it.name.contains("lock", true) }
        val lock = scripts.firstOrNull { it.name.contains("lock", true) }
        return arrayOf(clean, save, lock)
    }

    private fun onRomExtracted(scan: RomTools.Scan) {
        if (scan.scripts.isEmpty() && scan.images.isEmpty()) {
            romStateTv.text = if (scan.hasPayload) {
                "This is an OTA package (payload.bin). Not supported. Use the fastboot ROM (.tgz / .zip with flash_all script)."
            } else {
                "No flash script or .img files found in this file."
            }
            romStateTv.setTextColor(RED)
            romOptionsCard.visibility = View.GONE
            romReady = false
            updateButtons()
            return
        }
        romOptionsCard.visibility = View.VISIBLE
        if (scan.scripts.isEmpty()) {
            romStateTv.text = "Extracted: ${scan.images.size} image files (no flash script). Choose what to flash."
            romStateTv.setTextColor(GREEN)
            modeGroup.visibility = View.GONE
            imagesBox.visibility = View.VISIBLE
            imagesBox.removeAllViews()
            imageChecks.clear()
            for (img in scan.images) {
                val cb = CheckBox(this).apply {
                    text = "${img.name}  ->  ${img.nameWithoutExtension}"
                    setTextColor(TEXT)
                    isChecked = !img.name.contains("empty", true)
                }
                imageChecks.add(Pair(cb, img))
                imagesBox.addView(cb)
            }
            stepsTv.text = "Partition name = file name. Untick what you do not want."
            romReady = true
        } else {
            romStateTv.text = "Extracted. Choose a flash mode:"
            romStateTv.setTextColor(GREEN)
            imagesBox.visibility = View.GONE
            modeGroup.visibility = View.VISIBLE
            modeScripts = findModeScripts(scan.scripts)
            var first = -1
            for (i in 0 until 3) {
                val avail = modeScripts[i] != null
                modeButtons[i].isEnabled = avail
                modeButtons[i].alpha = if (avail) 1f else 0.35f
                if (avail && first < 0) first = i
            }
            if (first < 0) first = 0
            selectedMode = first
            modeButtons[first].isChecked = true
            refreshSteps()
        }
        updateButtons()
    }

    private fun refreshSteps() {
        val script = modeScripts[selectedMode]
        val dir = romDir
        if (script == null || dir == null) {
            stepsTv.text = "This ROM has no script for this mode."
            romReady = false
            updateButtons()
            return
        }
        val parsed = try {
            RomTools.parseScript(script, dir, allowLock = selectedMode == 2)
        } catch (e: Exception) {
            stepsTv.text = "Cannot read script: ${e.message}"
            romReady = false
            updateButtons()
            return
        }
        currentParsed = parsed
        val sb = StringBuilder()
        if (parsed.missingFiles.isNotEmpty()) {
            sb.append("Missing files in ROM:\n").append(parsed.missingFiles.joinToString("\n")).append("\n\n")
        }
        sb.append("Script: ${script.name}\n")
        sb.append("User data wiped: ").append(if (parsed.wipesData) "YES" else "no").append('\n')
        sb.append("Bootloader re-lock: ").append(if (hasLockStep(parsed.steps)) "YES" else "no").append('\n')
        if (parsed.warnings.isNotEmpty()) sb.append("\nNotes:\n").append(parsed.warnings.joinToString("\n")).append('\n')
        sb.append("\nSteps:\n")
        for (s in parsed.steps) sb.append("- ").append(s.describe()).append('\n')
        stepsTv.text = sb.toString().trimEnd()
        romReady = parsed.missingFiles.isEmpty() && parsed.steps.any { it.op == "flash" }
        updateButtons()
    }

    private fun hasLockStep(steps: List<Step>): Boolean =
        steps.any { it.op == "command" && Regex("""(^|\s)lock(\s|$)""").containsMatchIn(it.argument) }

    private fun onFlashRomClicked() {
        val scan = romScan ?: return
        val steps: List<Step>
        val modeName: String
        if (scan.scripts.isEmpty()) {
            steps = imageChecks.filter { it.first.isChecked }
                .map { Step("flash", partition = it.second.nameWithoutExtension, file = it.second) }
            modeName = "Selected images"
            if (steps.isEmpty()) {
                toast("Nothing selected")
                return
            }
        } else {
            val p = currentParsed ?: return
            if (p.missingFiles.isNotEmpty()) {
                toast("ROM files are missing")
                return
            }
            steps = p.steps
            modeName = MODE_TITLES[selectedMode]
        }
        val wipes = ParsedScript(steps, emptyList(), emptyList()).wipesData
        val locks = hasLockStep(steps)
        val msg = StringBuilder()
        msg.append("Mode: $modeName\n")
        msg.append("${steps.count { it.op == "flash" }} flash step(s)\n")
        msg.append("User data wiped: ").append(if (wipes) "YES" else "no").append('\n')
        msg.append("Bootloader will be RE-LOCKED: ").append(if (locks) "YES" else "no").append('\n')
        if (locks) {
            msg.append("\nRe-locking with a ROM that does not exactly match this phone, or an older ROM (anti-rollback), can brick it permanently.\n")
        }
        msg.append("\nDo not unplug the cable or close the app while flashing.")
        msg.append(unlockedWarning())
        val start = { withDevice("Flash ROM") { dev -> runSteps(dev, steps) } }
        confirm("Start flashing?", msg.toString(), "Flash") {
            if (locks) {
                ui.post {
                    askText("Type LOCK to confirm", "LOCK") {
                        if (it == "LOCK") start() else toast("Not confirmed")
                    }
                }
            } else {
                start()
            }
        }
    }

    private fun runSteps(dev: FastbootDevice, steps: List<Step>) {
        val max = dev.maxDownloadSize()
        totalBytes = steps.filter { it.op == "flash" }.sumOf { it.file?.length() ?: 0L }
        doneBytes = 0
        dev.onBytes = { addBytes(it) }
        for ((i, s) in steps.withIndex()) {
            if (cancelRequested) throw FastbootException("Cancelled by user")
            log("[${i + 1}/${steps.size}] ${s.describe()}")
            setProgressText("Step ${i + 1}/${steps.size}: ${s.describe()}")
            when (s.op) {
                "check_product" -> {
                    val p = dev.getvar("product")?.trim().orEmpty()
                    if (s.products.none { it.equals(p, true) }) {
                        throw FastbootException("Wrong ROM for this phone: device is '$p', ROM is for ${s.products.joinToString("/")}")
                    }
                }
                "flash" -> {
                    val part = dev.resolvePartition(s.partition)
                    dev.flashFile(part, s.file!!, max) { log(it) }
                }
                "erase" -> dev.send("erase:" + dev.resolvePartition(s.partition), 300_000) { log("  device: $it") }
                "set_active" -> dev.send("set_active:" + s.argument, 30_000)
                "reboot" -> {
                    dev.send(if (s.argument.isEmpty()) "reboot" else "reboot-" + s.argument, 30_000)
                    ui.post {
                        closeDevice()
                        setStatus("Device is rebooting", false)
                    }
                    return
                }
                "command" -> dev.send(s.argument, 120_000) { log("  device: $it") }
            }
        }
    }

    // ------------------------------------------------------------------ commands / tools

    private fun rebootTo(target: String) {
        withDevice("Reboot ${target.ifEmpty { "system" }}") { dev ->
            dev.send(if (target.isEmpty()) "reboot" else "reboot-$target", 30_000)
            ui.post {
                closeDevice()
                setStatus("Device is rebooting - reconnect when needed", false)
            }
        }
    }

    private fun setSlot(slot: String) {
        withDevice("Set active slot $slot") {
            it.send("set_active:$slot", 30_000)
            cmdOut("> set_active:$slot  [OKAY]")
        }
    }

    private fun erasePartition(part: String) {
        if (part.isEmpty()) {
            toast("Type the partition name")
            return
        }
        confirm(
            "Erase \"$part\"?",
            "This permanently deletes the contents of partition \"$part\". Erasing the wrong partition can brick the phone." + unlockedWarning(),
            "Erase",
        ) {
            withDevice("Erase $part") { dev ->
                cmdOut("> erase:$part")
                try {
                    dev.send("erase:" + dev.resolvePartition(part), 300_000) { cmdOut("  $it") }
                    cmdOut("  [OKAY]")
                } catch (e: Exception) {
                    cmdOut("  [FAIL] ${e.message}")
                    throw e
                }
            }
        }
    }

    private fun runCommand(cmd: String) {
        if (cmd.isEmpty()) {
            toast("Type a command first")
            return
        }
        val go = {
            withDevice("Command: $cmd") { dev ->
                cmdOut("> $cmd")
                try {
                    val r = dev.send(cmd, 120_000) { cmdOut("  $it") }
                    if (r.isNotEmpty()) cmdOut("  $r")
                    cmdOut("  [OKAY]")
                } catch (e: Exception) {
                    cmdOut("  [FAIL] ${e.message}")
                    throw e
                }
            }
        }
        if (Regex("""(^|[\s:])lock(\s|$)""").containsMatchIn(cmd.lowercase())) {
            confirm("Re-lock bootloader?", "This can brick the phone if the installed ROM is not official and exactly matching. Continue only if you are sure.", "Run") { go() }
        } else {
            go()
        }
    }

    private fun clearCache() {
        if (busy) {
            toast("Wait for the running task")
            return
        }
        var freed = 0L
        workDir().listFiles()?.forEach {
            freed += it.walkTopDown().filter { f -> f.isFile }.sumOf { f -> f.length() }
            it.deleteRecursively()
        }
        romReady = false
        romDir = null
        romScan = null
        romOptionsCard.visibility = View.GONE
        romNameTv.text = "No ROM selected"
        romStateTv.text = "Pick a ROM file to begin."
        romStateTv.setTextColor(MUTED)
        updateButtons()
        log("Cleared temporary files (${freed / 1048576} MB).")
    }

    // ------------------------------------------------------------------ UI building

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

    private fun matchWrap() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(BG)
        }

        // header
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(14), dp(18), dp(14))
            background = GradientDrawable(
                GradientDrawable.Orientation.LEFT_RIGHT,
                intArrayOf(0xFF1E2A5A.toInt(), 0xFF3B2A7A.toInt()),
            )
        }
        header.addView(txt("FastFlash OTG", 22f, bold = true, color = Color.WHITE))
        statusTv = txt("●  No fastboot device found", 13f, bold = true, color = RED)
        header.addView(statusTv)
        root.addView(header, matchWrap())

        // pages
        val frame = FrameLayout(this)
        root.addView(frame, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        val pDevice = buildDevicePage()
        val pRom = buildRomPage()
        val pImage = buildImagePage()
        val pCmd = buildCommandsPage()
        val pLog = buildLogPage()
        for (p in listOf(pDevice, pRom, pImage, pCmd, pLog)) {
            pages.add(p)
            frame.addView(p, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        }

        // progress panel
        progressPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(SURFACE2)
            setPadding(dp(16), dp(8), dp(16), dp(8))
            visibility = View.GONE
        }
        progressBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 1000 }
        progressTv = txt("Idle", 12f, color = TEXT)
        cancelBtn = Button(this).apply {
            text = "Cancel after current step"
            isAllCaps = false
            isEnabled = false
            setOnClickListener {
                cancelRequested = true
                log("Cancel requested - stopping after the current step.")
            }
        }
        progressPanel.addView(progressTv)
        progressPanel.addView(progressBar)
        progressPanel.addView(cancelBtn)
        root.addView(progressPanel, matchWrap())

        // bottom navigation
        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(SURFACE)
        }
        val labels = listOf("📱\nDevice", "📦\nROM", "💾\nImage", "⌨\nCommands", "📜\nLog")
        for ((i, l) in labels.withIndex()) {
            val t = TextView(this).apply {
                text = l
                gravity = Gravity.CENTER
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
                setPadding(0, dp(8), 0, dp(8))
                setOnClickListener { showPage(i) }
            }
            navItems.add(t)
            nav.addView(t, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        }
        root.addView(nav, matchWrap())

        setContentView(root)
        showPage(0)
    }

    private fun showPage(index: Int) {
        for ((i, p) in pages.withIndex()) p.visibility = if (i == index) View.VISIBLE else View.GONE
        for ((i, n) in navItems.withIndex()) n.setTextColor(if (i == index) ACCENT else MUTED)
    }

    private fun newPage(): Pair<ScrollView, LinearLayout> {
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(14), dp(14), dp(20))
        }
        val sv = ScrollView(this).apply {
            isFillViewport = true
            addView(content)
        }
        return Pair(sv, content)
    }

    private fun buildDevicePage(): View {
        val (sv, c) = newPage()
        val info = card(c, "Phone info")
        infoTv = txt("No data. Connect a phone in fastboot mode.", 12f, mono = true, color = TEXT)
        info.addView(infoTv)
        info.addView(row(
            btn("Connect", primary = true) { connect() },
            btn("Refresh info") { refreshInfo() },
        ))

        val reboot = card(c, "Reboot target phone")
        reboot.addView(row(
            btn("System") { rebootTo("") },
            btn("Bootloader") { rebootTo("bootloader") },
        ))
        reboot.addView(row(
            btn("Recovery") { rebootTo("recovery") },
            btn("Fastbootd") { rebootTo("fastboot") },
        ))

        val help = card(c, "How to connect")
        help.addView(txt(
            "1. Switch the target phone off, then hold Power + Volume Down to enter fastboot mode.\n" +
                "2. Connect the target phone to this phone with a USB-C OTG cable.\n" +
                "3. Allow the USB permission popup.\n" +
                "The bootloader of the target phone must be unlocked.",
            13f, color = MUTED,
        ))
        return sv
    }

    private fun buildRomPage(): View {
        val (sv, c) = newPage()
        val pick = card(c, "Fastboot ROM")
        romNameTv = txt("No ROM selected", 15f, bold = true, color = TEXT)
        romStateTv = txt("Pick a ROM file (.zip or .tgz). It is extracted automatically.", 12f, color = MUTED)
        pick.addView(romNameTv)
        pick.addView(romStateTv)
        pick.addView(btn("Select ROM file", primary = true) { pickFile(REQ_ROM) })

        romOptionsCard = card(c, "Flash options")
        romOptionsCard.visibility = View.GONE
        modeGroup = RadioGroup(this).apply { orientation = RadioGroup.VERTICAL }
        for (i in 0 until 3) {
            val rb = RadioButton(this).apply {
                id = View.generateViewId()
                text = MODE_TITLES[i] + "\n" + MODE_DESCS[i]
                setTextColor(if (i == 2) AMBER else TEXT)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
                setPadding(dp(4), dp(8), 0, dp(8))
            }
            modeButtons.add(rb)
            modeGroup.addView(rb, matchWrap())
        }
        modeGroup.setOnCheckedChangeListener { _, checkedId ->
            val idx = modeButtons.indexOfFirst { it.id == checkedId }
            if (idx >= 0 && idx != selectedMode) {
                selectedMode = idx
                refreshSteps()
            }
        }
        romOptionsCard.addView(modeGroup, matchWrap())
        imagesBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
        }
        romOptionsCard.addView(imagesBox, matchWrap())
        romOptionsCard.addView(txt("Steps that will run", 13f, bold = true, color = TEXT))
        stepsTv = txt("", 11f, mono = true, color = MUTED)
        romOptionsCard.addView(stepsTv)
        flashRomBtn = btn("Flash ROM", primary = true) { onFlashRomClicked() }
        actionButtons.remove(flashRomBtn)
        flashRomBtn.isEnabled = false
        flashRomBtn.alpha = 0.4f
        romOptionsCard.addView(flashRomBtn, matchWrap().apply { topMargin = dp(8) })

        val clean = card(c, "Storage")
        clean.addView(txt("Extracted ROM files use a lot of space. Delete them when finished.", 12f, color = MUTED))
        clean.addView(btn("Clear temporary files") { clearCache() })
        return sv
    }

    private fun buildImagePage(): View {
        val (sv, c) = newPage()
        val flash = card(c, "Flash one image")
        partitionEt = input("Partition name, e.g. boot")
        flash.addView(partitionEt, matchWrap())
        val chips = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
        val chipRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for (p in listOf("boot", "init_boot", "vendor_boot", "recovery", "dtbo", "vbmeta", "super")) {
            chipRow.addView(chip(p) { partitionEt.setText(p) })
        }
        chips.addView(chipRow)
        flash.addView(chips)
        flash.addView(btn("Choose image and flash", primary = true) {
            if (partitionEt.text.toString().trim().isEmpty()) toast("Type the partition name first") else pickFile(REQ_IMAGE)
        }, matchWrap().apply { topMargin = dp(8) })

        val boot = card(c, "Boot image once")
        boot.addView(txt("Boots an image temporarily (for example a recovery) without writing it to the phone.", 12f, color = MUTED))
        boot.addView(btn("Choose image and boot") { pickFile(REQ_BOOT) })
        return sv
    }

    private fun buildCommandsPage(): View {
        val (sv, c) = newPage()

        val run = card(c, "Run fastboot command")
        cmdEt = input("e.g. getvar:product or oem device-info")
        run.addView(cmdEt, matchWrap())
        val chips = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
        val chipRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for (p in listOf("getvar:all", "getvar:product", "getvar:unlocked", "getvar:current-slot", "oem device-info")) {
            chipRow.addView(chip(p) { cmdEt.setText(p) })
        }
        chips.addView(chipRow)
        run.addView(chips)
        run.addView(btn("Run command", primary = true) { runCommand(cmdEt.text.toString().trim()) }, matchWrap().apply { topMargin = dp(8) })

        val getvar = card(c, "Get variable")
        varEt = input("variable name, e.g. serialno")
        getvar.addView(varEt, matchWrap())
        getvar.addView(btn("Get variable") {
            val v = varEt.text.toString().trim()
            if (v.isEmpty()) toast("Type a variable name") else runCommand("getvar:$v")
        })

        val slot = card(c, "Active slot")
        slot.addView(row(
            btn("Set slot A") { setSlot("a") },
            btn("Set slot B") { setSlot("b") },
        ))

        val erase = card(c, "Erase partition")
        erase.addView(txt("Dangerous. Erasing the wrong partition can brick the phone.", 12f, color = AMBER))
        eraseEt = input("partition name, e.g. userdata")
        erase.addView(eraseEt, matchWrap())
        erase.addView(btn("Erase", danger = true) { erasePartition(eraseEt.text.toString().trim()) })

        val out = card(c, "Output")
        cmdOutTv = txt("", 11f, mono = true, color = TEXT).apply { setTextIsSelectable(true) }
        out.addView(cmdOutTv)
        out.addView(chip("Clear output") {
            synchronized(cmdOutBuf) { cmdOutBuf.setLength(0) }
            cmdOutTv.text = ""
        })
        return sv
    }

    private fun buildLogPage(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(14), dp(14), dp(14))
        }
        logTv = txt("", 11f, mono = true, color = TEXT).apply { setTextIsSelectable(true) }
        logScroll = ScrollView(this).apply {
            addView(logTv)
            background = GradientDrawable().apply {
                setColor(SURFACE)
                cornerRadius = dp(12).toFloat()
            }
            setPadding(dp(10), dp(8), dp(10), dp(8))
        }
        root.addView(logScroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        root.addView(row(
            chipButton("Copy log") {
                val text = synchronized(logBuf) { logBuf.toString() }
                (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager)
                    .setPrimaryClip(ClipData.newPlainText("FastFlash log", text))
                toast("Log copied")
            },
            chipButton("Clear log") {
                synchronized(logBuf) { logBuf.setLength(0) }
                logTv.text = ""
            },
        ))
        return root
    }

    // ------------------------------------------------------------------ view helpers

    private fun card(parent: LinearLayout, title: String): LinearLayout {
        val c = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(12), dp(14), dp(14))
            background = GradientDrawable().apply {
                setColor(SURFACE)
                cornerRadius = dp(16).toFloat()
            }
        }
        c.addView(txt(title, 15f, bold = true, color = Color.WHITE))
        parent.addView(c, matchWrap().apply { bottomMargin = dp(12) })
        return c
    }

    private fun txt(
        s: String,
        sizeSp: Float,
        bold: Boolean = false,
        mono: Boolean = false,
        color: Int = TEXT,
    ): TextView = TextView(this).apply {
        text = s
        setTextSize(TypedValue.COMPLEX_UNIT_SP, sizeSp)
        setTextColor(color)
        if (mono) typeface = Typeface.MONOSPACE else if (bold) typeface = Typeface.DEFAULT_BOLD
        setPadding(0, dp(4), 0, dp(4))
    }

    private fun input(hintText: String): EditText = EditText(this).apply {
        hint = hintText
        setHintTextColor(MUTED)
        setTextColor(TEXT)
        inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        setSingleLine(true)
    }

    private fun roundBg(fill: Int, radiusDp: Int): RippleDrawable {
        val shape = GradientDrawable().apply {
            setColor(fill)
            cornerRadius = dp(radiusDp).toFloat()
        }
        return RippleDrawable(ColorStateList.valueOf(0x33FFFFFF), shape, null)
    }

    /** Main action button: disabled while a task runs. */
    private fun btn(label: String, primary: Boolean = false, danger: Boolean = false, onClick: () -> Unit): Button {
        val b = chipButton(label, onClick)
        val fill = if (danger) RED_DARK else if (primary) ACCENT else SURFACE2
        b.background = roundBg(fill, 12)
        b.minHeight = dp(46)
        b.minimumHeight = dp(46)
        actionButtons.add(b)
        return b
    }

    /** Button that stays enabled while tasks run. */
    private fun chipButton(label: String, onClick: () -> Unit): Button = Button(this).apply {
        text = label
        isAllCaps = false
        setTextColor(Color.WHITE)
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
        background = roundBg(SURFACE2, 12)
        stateListAnimator = null
        setOnClickListener { onClick() }
    }

    private fun chip(label: String, onClick: () -> Unit): TextView = TextView(this).apply {
        text = label
        setTextColor(TEXT)
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
        background = roundBg(SURFACE2, 16)
        setPadding(dp(12), dp(6), dp(12), dp(6))
        setOnClickListener { onClick() }
        layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
        ).apply {
            marginEnd = dp(6)
            topMargin = dp(4)
            bottomMargin = dp(4)
        }
    }

    private fun row(vararg buttons: Button): LinearLayout {
        val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for ((i, b) in buttons.withIndex()) {
            val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                topMargin = dp(8)
                if (i > 0) marginStart = dp(8)
            }
            r.addView(b, lp)
        }
        return r
    }
}
