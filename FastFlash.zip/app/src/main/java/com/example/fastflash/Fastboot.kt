package com.example.fastflash

import android.hardware.usb.UsbConstants
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbDeviceConnection
import android.hardware.usb.UsbEndpoint
import android.hardware.usb.UsbInterface
import android.hardware.usb.UsbManager
import java.io.File
import java.io.IOException
import java.io.RandomAccessFile

class FastbootException(message: String) : IOException(message)

/** Receives raw bytes that are being streamed to the device during "download:". */
interface DataSink {
    fun write(buf: ByteArray, off: Int, len: Int)
}

/**
 * Minimal fastboot protocol client over Android USB host API.
 * Protocol: https://android.googlesource.com/platform/system/core/+/master/fastboot/README.md
 */
class FastbootDevice private constructor(
    private val connection: UsbDeviceConnection,
    private val iface: UsbInterface,
    private val inEp: UsbEndpoint,
    private val outEp: UsbEndpoint,
) : AutoCloseable {

    /** Called with the number of bytes written for every chunk during download. */
    @Volatile
    var onBytes: ((Long) -> Unit)? = null

    companion object {
        /** Safe size for a single USB bulk transfer on all Android versions. */
        const val CHUNK = 16384

        fun findInterface(dev: UsbDevice): UsbInterface? {
            for (i in 0 until dev.interfaceCount) {
                val itf = dev.getInterface(i)
                if (itf.interfaceClass == 0xFF && itf.interfaceSubclass == 0x42 && itf.interfaceProtocol == 0x03) {
                    return itf
                }
            }
            return null
        }

        fun open(manager: UsbManager, dev: UsbDevice): FastbootDevice {
            val itf = findInterface(dev) ?: throw FastbootException("Device has no fastboot interface")
            var inEp: UsbEndpoint? = null
            var outEp: UsbEndpoint? = null
            for (i in 0 until itf.endpointCount) {
                val ep = itf.getEndpoint(i)
                if (ep.type != UsbConstants.USB_ENDPOINT_XFER_BULK) continue
                if (ep.direction == UsbConstants.USB_DIR_IN) inEp = ep else outEp = ep
            }
            if (inEp == null || outEp == null) throw FastbootException("Fastboot bulk endpoints not found")
            val conn = manager.openDevice(dev) ?: throw FastbootException("Cannot open USB device (permission?)")
            if (!conn.claimInterface(itf, true)) {
                conn.close()
                throw FastbootException("Cannot claim fastboot interface")
            }
            return FastbootDevice(conn, itf, inEp, outEp)
        }
    }

    override fun close() {
        try {
            connection.releaseInterface(iface)
        } catch (_: Exception) {
        }
        try {
            connection.close()
        } catch (_: Exception) {
        }
    }

    // ---------------------------------------------------------------- low level

    private fun writeAll(buf: ByteArray, off: Int, len: Int, timeoutMs: Int = 30_000) {
        var pos = 0
        while (pos < len) {
            val n = minOf(CHUNK, len - pos)
            val r = connection.bulkTransfer(outEp, buf, off + pos, n, timeoutMs)
            if (r < 0) throw FastbootException("USB write failed (cable disconnected?)")
            pos += r
            onBytes?.invoke(r.toLong())
        }
    }

    private class Response(val type: String, val text: String)

    private fun readResponse(timeoutMs: Long): Response {
        val deadline = System.currentTimeMillis() + timeoutMs
        val buf = ByteArray(512)
        while (true) {
            val n = connection.bulkTransfer(inEp, buf, buf.size, 1000)
            if (n >= 4) {
                val s = String(buf, 0, n, Charsets.UTF_8)
                return Response(s.substring(0, 4), s.substring(4))
            }
            if (System.currentTimeMillis() > deadline) {
                throw FastbootException("Timeout waiting for device response")
            }
            if (n < 0) Thread.sleep(30)
        }
    }

    // ---------------------------------------------------------------- commands

    /**
     * Sends a command and waits for OKAY. INFO/TEXT lines are passed to [onInfo].
     * Returns the text after OKAY. Throws on FAIL.
     */
    fun send(cmd: String, timeoutMs: Long = 30_000, onInfo: ((String) -> Unit)? = null): String {
        val bytes = cmd.toByteArray(Charsets.UTF_8)
        if (bytes.size > 4096) throw FastbootException("Command too long")
        writeAllNoCount(bytes)
        while (true) {
            val r = readResponse(timeoutMs)
            when (r.type) {
                "OKAY" -> return r.text
                "FAIL" -> throw FastbootException(r.text.ifEmpty { "FAIL" })
                "INFO", "TEXT" -> onInfo?.invoke(r.text)
                else -> throw FastbootException("Unexpected response: ${r.type}${r.text}")
            }
        }
    }

    private fun writeAllNoCount(bytes: ByteArray) {
        val r = connection.bulkTransfer(outEp, bytes, bytes.size, 10_000)
        if (r < 0) throw FastbootException("USB write failed (cable disconnected?)")
    }

    fun getvar(name: String): String? = try {
        send("getvar:$name", 10_000)
    } catch (e: FastbootException) {
        null
    }

    fun getAllVars(): List<String> {
        val out = ArrayList<String>()
        send("getvar:all", 30_000) { out.add(it) }
        return out
    }

    /** Parses max-download-size (hex "0x..." or decimal). Falls back to 256 MiB, caps at 1 GiB. */
    fun maxDownloadSize(): Long {
        val v = getvar("max-download-size")?.trim().orEmpty()
        val parsed = try {
            if (v.startsWith("0x", true)) v.substring(2).toLong(16) else v.toLong()
        } catch (e: NumberFormatException) {
            0L
        }
        val size = if (parsed <= 0L) 256L * 1024 * 1024 else parsed
        return minOf(size, 1024L * 1024 * 1024)
    }

    /** Same slot logic as the desktop fastboot tool: add current slot suffix if partition is A/B. */
    fun resolvePartition(name: String): String {
        if (name.endsWith("_a") || name.endsWith("_b") || name.endsWith("_ab")) return name
        if (getvar("has-slot:$name") == "yes") {
            val slot = getvar("current-slot")?.trim().orEmpty()
            if (slot.isNotEmpty()) return "${name}_$slot"
        }
        return name
    }

    /** Streams [size] bytes produced by [producer] to the device using "download:". */
    fun download(size: Long, producer: (DataSink) -> Unit) {
        val cmd = "download:" + String.format("%08x", size)
        writeAllNoCount(cmd.toByteArray())
        val r = readResponse(30_000)
        if (r.type == "FAIL") throw FastbootException(r.text)
        if (r.type != "DATA") throw FastbootException("Unexpected response to download: ${r.type}${r.text}")
        val expected = r.text.trim().toLong(16)
        if (expected != size) throw FastbootException("Device expected $expected bytes, tried $size")

        var sent = 0L
        val sink = object : DataSink {
            override fun write(buf: ByteArray, off: Int, len: Int) {
                writeAll(buf, off, len)
                sent += len
            }
        }
        producer(sink)
        if (sent != size) throw FastbootException("Internal error: sent $sent of $size bytes")
        while (true) {
            val end = readResponse(120_000)
            when (end.type) {
                "OKAY" -> return
                "FAIL" -> throw FastbootException(end.text)
                "INFO", "TEXT" -> {}
                else -> throw FastbootException("Unexpected response: ${end.type}${end.text}")
            }
        }
    }

    // ---------------------------------------------------------------- high level helpers

    fun downloadWholeFile(file: File) {
        download(file.length()) { sink ->
            RandomAccessFile(file, "r").use { raf ->
                val buf = ByteArray(1 shl 20)
                while (true) {
                    val n = raf.read(buf)
                    if (n <= 0) break
                    sink.write(buf, 0, n)
                }
            }
        }
    }

    /**
     * Flashes [file] to [partition]. Large images are split into several
     * sparse pieces that fit into the device's max-download-size.
     */
    fun flashFile(partition: String, file: File, maxDownload: Long, log: (String) -> Unit) {
        val size = file.length()
        if (size <= maxDownload) {
            downloadWholeFile(file)
            send("flash:$partition", 300_000) { log("  device: $it") }
            return
        }
        val plan = SparseTools.plan(file, maxDownload)
        log("  image is larger than max-download-size, sending ${plan.pieces.size} pieces")
        RandomAccessFile(file, "r").use { raf ->
            for ((i, piece) in plan.pieces.withIndex()) {
                val emits = SparseTools.emitsFor(piece, plan.totalBlocks)
                val pieceSize = SparseTools.sizeOf(emits, plan.blockSize)
                log("  piece ${i + 1}/${plan.pieces.size} ($pieceSize bytes)")
                download(pieceSize) { sink ->
                    SparseTools.writePiece(raf, emits, plan.blockSize, plan.totalBlocks, sink)
                }
                send("flash:$partition", 300_000) { log("  device: $it") }
            }
        }
    }
}
