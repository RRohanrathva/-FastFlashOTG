# FastFlash OTG

Android app: ek phone thi (USB-OTG cable vaDe) bija Xiaomi / Android phone ne **fastboot mode** ma flash kare chhe.
(Windows "Xiaomi Service" jevo tool, pan Android par.)

## Features
- Fastboot device auto-detect (USB OTG), device info (product, slot, unlocked, max-download-size ...)
- Ek image flash karvi (boot, recovery, vendor_boot ...)
- Fastboot ROM flash: `.zip` / `.tgz` auto-extract, pachhi Mi Flash jevi 3 option: **Clean all / Save user data / Clean all and lock**
  - Wrong-phone ROM check (`getvar product`)
  - Moti image (super.img) automatic sparse pieces ma split
  - Bootloader re-lock steps safety mate skip
- Reboot (system / bootloader / recovery / fastbootd), set active slot, erase partition, boot image once, custom command

## APK GitHub par thi banavvo
1. GitHub par navu repository banavo (e.g. `FastFlashOTG`).
2. Aa zip na andar ni badhi files repository ma upload karo (folder ni andar ni files, `.github` folder sathe).
3. Repository -> **Actions** tab -> **Build APK** -> **Run workflow** (ke push thaye etle automatic chalshe).
4. 3-5 minute pachhi run ma **Artifacts** -> `FastFlashOTG-debug-apk` download karo -> andar `app-debug.apk`.
5. APK phone ma install karo ("Install unknown apps" allow karvu pade).

Build fail thay to Actions ma error log copy kari ne mokalo.

## Vaparvanu
1. Target phone ne fastboot mode ma mukho (Power + Volume Down). Bootloader **unlocked** hovu joiye.
2. Aa app vaala phone ma OTG cable lagao, target phone cable thi jodo.
3. App ma USB permission allow karo -> "Connected (fastboot)" dekhashe.

## Limits
- Bootloader unlock (Mi Unlock) aa app ma nathi - Xiaomi nu official process (Mi account + wait time) PC par j chale.
- OTA `payload.bin` support nathi - fastboot ROM vapro.
- Flash chalu hoy tyare app band na karo, cable na kadho.
- Aa app ni project Android SDK vagar lakhi chhe; pehli vaar build ma nano compile error aave to log mokalo, hu fix kari aapish.
